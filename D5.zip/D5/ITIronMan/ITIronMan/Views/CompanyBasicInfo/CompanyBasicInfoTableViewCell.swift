//
//  CompanyBasicInfoTableViewCell.swift
//  ITIronMan
//
//  Created by cm0679 on 2021/9/4.
//

import UIKit

class CompanyBasicInfoTableViewCell: UITableViewCell {

    static let identifier = "CompanyBasicInfoTableViewCell"
    
    @IBOutlet weak var codeAndNameLabel: UILabel!
    
    @IBOutlet weak var capitalLabel: UILabel!
}
